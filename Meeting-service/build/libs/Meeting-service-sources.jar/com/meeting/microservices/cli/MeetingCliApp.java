package com.meeting.microservices.cli;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 * Petit client CLI pour interagir avec les endpoints REST du Meeting-service.
 */
@SuppressWarnings("java:S106")
public final class MeetingCliApp {

    private static final String BASE_URL = "http://localhost:8080/api/meeting";
    private static final String HEADER_ACCEPT = "Accept";
    private static final String HEADER_CONTENT_TYPE = "Content-Type";
    private static final String MIME_JSON = "application/json";
    private static final String PROMPT_MEETING_ID = "ID de la réunion : ";
    private static final String PROMPT_PARTICIPANT_ID = "ID du participant : ";
    private static final String PROMPT_FIRSTNAME = "Prénom : ";
    private static final String PROMPT_LASTNAME = "Nom : ";
    private static final String PROMPT_EMAIL = "Email (optionnel) : ";
    private static final String STATUS_SCHEDULED = "scheduled";
    private static final List<String> STATUS_OPTIONS = List.of(
            STATUS_SCHEDULED,
            "in_progress",
            "completed",
            "postponed",
            "cancelled"
    );
    private static final List<String> STATUS_DISPLAY = List.of(
            STATUS_OPTIONS.get(0) + " (Planifiée)",
            STATUS_OPTIONS.get(1) + " (En cours)",
            STATUS_OPTIONS.get(2) + " (Terminée)",
            STATUS_OPTIONS.get(3) + " (Reportée)",
            STATUS_OPTIONS.get(4) + " (Annulée)"
    );

    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    private MeetingCliApp() {
        // Utility class
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8)) {
            boolean running = true;
            while (running) {
                printMenu();
                System.out.print("Votre choix : ");
                String choice = scanner.nextLine().trim();
                switch (choice) {
                    case "1" -> createMeeting(scanner);
                    case "2" -> listMeetings();
                    case "3" -> getMeetingById(scanner);
                    case "4" -> listParticipants(scanner);
                    case "5" -> addParticipant(scanner);
                    case "6" -> removeParticipant(scanner);
                    case "7" -> searchByTitle(scanner);
                    case "8" -> startMeeting(scanner);
                    case "9" -> updateStatus(scanner);
                    case "0" -> running = false;
                    default -> System.out.println("Option inconnue, merci de réessayer.\n");
                }
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n=== Menu Meeting Service ===");
        System.out.println("1. Créer une réunion");
        System.out.println("2. Lister toutes les réunions");
        System.out.println("3. Consulter une réunion par ID");
        System.out.println("4. Lister les participants d'une réunion");
        System.out.println("5. Ajouter un participant à une réunion");
        System.out.println("6. Retirer un participant d'une réunion");
        System.out.println("7. Rechercher des réunions par titre");
        System.out.println("8. Démarrer une réunion");
        System.out.println("9. Modifier le statut d'une réunion");
        System.out.println("0. Quitter");
    }

    private static void createMeeting(Scanner scanner) {
        System.out.println("\nCréation d'une réunion");
        System.out.print("Titre : ");
        String title = scanner.nextLine();
        System.out.print("Description : ");
        String description = scanner.nextLine();
        System.out.print("Date et heure (ex: 2025-11-07T10:00:00Z) : ");
        String scheduledAt = scanner.nextLine().trim();
        System.out.print("Durée prévue (minutes ou hh:mm) : ");
        Integer durationMinutes = parseDurationInput(scanner.nextLine());

        List<String> participantsJson = new ArrayList<>();
        while (true) {
            System.out.print("Ajouter un participant ? (o/n) : ");
            String answer = scanner.nextLine().trim().toLowerCase(Locale.ROOT);
            if (!"o".equals(answer)) {
                break;
            }
            String participantPayload = promptParticipantPayload(scanner, "Prénom et nom vides, participant ignoré.");
            if (participantPayload != null) {
                participantsJson.add(participantPayload);
            }
        }

        String participantsArray = participantsJson.isEmpty()
                ? "[]"
                : "[" + String.join(",", participantsJson) + "]";

        List<String> fields = new ArrayList<>();
        fields.add("\"title\":\"" + escapeJson(title) + "\"");
        fields.add("\"description\":\"" + escapeJson(description) + "\"");
        fields.add("\"scheduledAt\":\"" + escapeJson(scheduledAt) + "\"");
        if (durationMinutes != null) {
            fields.add("\"durationMinutes\":" + durationMinutes);
        }
        fields.add(buildStatusField(STATUS_SCHEDULED));
        fields.add("\"participants\":" + participantsArray);

        String payload = "{" + String.join(",", fields) + "}";

        sendPost("", payload);
    }

    private static void listMeetings() {
        sendGet("/all");
    }

    private static void getMeetingById(Scanner scanner) {
        Long id = readLong(scanner, PROMPT_MEETING_ID);
        if (id != null) {
            sendGet("/" + id);
        }
    }

    private static void listParticipants(Scanner scanner) {
        Long id = readLong(scanner, PROMPT_MEETING_ID);
        if (id != null) {
            sendGet("/" + id + "/participant/all");
        }
    }

    private static void addParticipant(Scanner scanner) {
        Long meetingId = readLong(scanner, PROMPT_MEETING_ID);
        if (meetingId == null) {
            return;
        }
        String payload = promptParticipantPayload(scanner, "Prénom et nom vides, participant non créé.");
        if (payload == null) {
            return;
        }

        sendPost("/" + meetingId + "/participant", payload);
    }

    private static void removeParticipant(Scanner scanner) {
        Long meetingId = readLong(scanner, PROMPT_MEETING_ID);
        if (meetingId == null) {
            return;
        }
        Long participantId = readLong(scanner, PROMPT_PARTICIPANT_ID);
        if (participantId != null) {
            sendDelete("/" + meetingId + "/participant/" + participantId);
        }
    }

    private static void startMeeting(Scanner scanner) {
        Long meetingId = readLong(scanner, PROMPT_MEETING_ID);
        if (meetingId != null) {
            sendPost("/" + meetingId + "/start", "{}");
        }
    }

    private static void updateStatus(Scanner scanner) {
        Long meetingId = readLong(scanner, PROMPT_MEETING_ID);
        if (meetingId == null) {
            return;
        }
        String status = chooseStatus(scanner);
        String payload = "{" + buildStatusField(status) + "}";
        sendPut("/" + meetingId + "/status", payload);
    }

    private static void searchByTitle(Scanner scanner) {
        System.out.print("Mot clé du titre : ");
        String keyword = scanner.nextLine();
        String path = "/search/byTitle?title=" + urlEncode(keyword);
        sendGet(path);
    }

    private static Integer parseDurationInput(String input) {
        if (input == null) {
            return null;
        }
        String trimmed = input.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.contains(":")) {
            String[] parts = trimmed.split(":", 2);
            try {
                int hours = Integer.parseInt(parts[0].trim());
                int minutes = Integer.parseInt(parts[1].trim());
                return Math.max((hours * 60) + minutes, 0);
            } catch (NumberFormatException e) {
                System.out.println("Format hh:mm invalide, durée ignorée.");
                return null;
            }
        }
        try {
            int value = Integer.parseInt(trimmed);
            return Math.max(value, 0);
        } catch (NumberFormatException e) {
            System.out.println("Durée invalide, durée ignorée.");
            return null;
        }
    }

    private static void sendGet(String path) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + path))
                .GET()
                .header(HEADER_ACCEPT, MIME_JSON)
                .build();
        sendRequest(request);
    }

    private static void sendPost(String path, String jsonPayload) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + path))
                .header(HEADER_CONTENT_TYPE, MIME_JSON)
                .header(HEADER_ACCEPT, MIME_JSON)
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload, StandardCharsets.UTF_8))
                .build();
        sendRequest(request);
    }

    private static void sendPut(String path, String jsonPayload) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + path))
                .header(HEADER_CONTENT_TYPE, MIME_JSON)
                .header(HEADER_ACCEPT, MIME_JSON)
                .PUT(HttpRequest.BodyPublishers.ofString(jsonPayload, StandardCharsets.UTF_8))
                .build();
        sendRequest(request);
    }

    private static void sendDelete(String path) {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + path))
                .DELETE()
                .header(HEADER_ACCEPT, MIME_JSON)
                .build();
        sendRequest(request);
    }

    private static void sendRequest(HttpRequest request) {
        try {
            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            System.out.println("\nCode HTTP : " + response.statusCode());
            System.out.println("Réponse : " + response.body());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Appel HTTP interrompu, opération annulée.");
        } catch (IOException e) {
            StringBuilder message = new StringBuilder();
            if (e.getMessage() != null && !e.getMessage().isBlank()) {
                message.append(e.getMessage());
            } else {
                message.append(e.getClass().getSimpleName());
            }
            Throwable cause = e.getCause();
            if (cause != null && cause.getMessage() != null && !cause.getMessage().isBlank()) {
                message.append(" - cause: ").append(cause.getMessage());
            }
            System.err.println("Erreur lors de l'appel HTTP : " + message);
        }
    }

    private static Long readLong(Scanner scanner, String prompt) {
        System.out.print(prompt);
        String value = scanner.nextLine().trim();
        if (value.isEmpty()) {
            System.out.println("Valeur vide, opération annulée.");
            return null;
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            System.out.println("Nombre invalide : " + value);
            return null;
        }
    }

    private static String chooseStatus(Scanner scanner) {
        while (true) {
            System.out.println("\nStatuts disponibles :");
            for (int i = 0; i < STATUS_OPTIONS.size(); i++) {
                System.out.println((i + 1) + ". " + STATUS_DISPLAY.get(i));
            }
            System.out.print("Statut cible : ");
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                return STATUS_OPTIONS.get(0);
            }
            try {
                int index = Integer.parseInt(input) - 1;
                if (index >= 0 && index < STATUS_OPTIONS.size()) {
                    return STATUS_OPTIONS.get(index);
                }
            } catch (NumberFormatException ignored) {
                // fall back to direct match
            }
            for (String option : STATUS_OPTIONS) {
                if (option.equalsIgnoreCase(input)) {
                    return option;
                }
            }
            System.out.println("Statut invalide, merci de choisir parmi la liste.");
        }
    }

    private static String promptParticipantPayload(Scanner scanner, String emptyWarning) {
        System.out.print(PROMPT_FIRSTNAME);
        String firstname = scanner.nextLine().trim();
        System.out.print(PROMPT_LASTNAME);
        String lastname = scanner.nextLine().trim();
        String fullName = combineFullName(firstname, lastname);
        if (fullName.isEmpty()) {
            System.out.println(emptyWarning);
            return null;
        }
        System.out.print(PROMPT_EMAIL);
        String email = scanner.nextLine().trim();

        StringBuilder payloadBuilder = new StringBuilder("{\"fullName\":\"")
                .append(escapeJson(fullName))
                .append("\"");
        if (!email.isEmpty()) {
            payloadBuilder.append(",\"email\":\"")
                    .append(escapeJson(email))
                    .append("\"");
        }
        payloadBuilder.append("}");
        return payloadBuilder.toString();
    }

    private static String buildStatusField(String statusValue) {
        return "\"status\":\"" + escapeJson(statusValue) + "\"";
    }

    private static String combineFullName(String firstname, String lastname) {
        StringBuilder builder = new StringBuilder();
        if (!firstname.isBlank()) {
            builder.append(firstname.trim());
        }
        if (!lastname.isBlank()) {
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(lastname.trim());
        }
        return builder.toString().trim();
    }

    private static String escapeJson(String input) {
        return input.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String urlEncode(String value) {
        return java.net.URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
